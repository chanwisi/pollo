# VERSION PYGBAG AUTOADAPTADA
# Ejecutar:
#   pip install pygbag
#   python -m pygbag .
#
# Nota:
# Esta adaptacion aplica cambios automaticos seguros.
# Aun puede requerir ajustes manuales de asyncio segun la version de PyBag.
#

# LEYES DE SIGNOS DELUXE FINAL
# Requiere: pip install pygame
# Coloca misun.mp3 junto a este archivo

import pygame, random, os, json, sys
import asyncio

pygame.init()
try:
    pygame.mixer.init()
except:
    pass

ANCHO = 1280
ALTO = 720

pantalla = pygame.display.set_mode((ANCHO, ALTO))
pygame.display.set_caption("juego de leyes de signos")

BASE = os.path.dirname(os.path.abspath(__file__))

# Musica
try:
    pygame.mixer.music.load(os.path.join(BASE,"misun.ogg"))
    pygame.mixer.music.set_volume(0.35)
    pygame.mixer.music.play(-1)
except Exception as e:
    print("Musica:", e)

# Colores Game Boy
BG1=(15,56,15)
BG2=(48,98,48)
BG3=(139,172,15)
BG4=(155,188,15)
WHITE=(255,255,255)
RED=(220,60,60)
YELLOW=(255,220,50)

FONT = pygame.font.SysFont("consolas", 28)
FONTM = pygame.font.SysFont("consolas", 44)
FONTG = pygame.font.SysFont("consolas", 72)

record_file = os.path.join(BASE, "record_leyes_signos.json")

def cargar_record():
    try:
        return json.load(open(record_file)).get("record",0)
    except:
        return 0

def guardar_record(v):
    json.dump({"record":v},open(record_file,"w"))

record=cargar_record()

nivel = 1
tiempo_limite = 12

vidas = 3
aciertos = 0
racha = 0

mensaje = ""

shake = 0
particulas = []

pregunta = ""
correcta = ""
respuesta = ""

inicio = 0

def fondo():
    for y in range(ALTO):
        c=int(15+(y/ALTO)*80)
        pygame.draw.line(pantalla,(15,c//2,c),(0,y),(ANCHO,y))

def scanlines():
    for y in range(0,ALTO,4):
        pygame.draw.line(pantalla,(0,0,0),(0,y),(ANCHO,y))

def boton(txt,x,y,w,h,color):
    r=pygame.Rect(x,y,w,h)
    pygame.draw.rect(pantalla,color,r,border_radius=12)
    pygame.draw.rect(pantalla,WHITE,r,2,border_radius=12)
    t=FONT.render(txt,True,WHITE)
    pantalla.blit(t,(r.centerx-t.get_width()/2,r.centery-t.get_height()/2))
    return r

def fade():
    s=pygame.Surface((ANCHO,ALTO))
    s.fill((0,0,0))
    for a in range(0,220,20):
        s.set_alpha(a)
        pantalla.blit(s,(0,0))
        pygame.display.flip()

def operacion(n):

    # ---------------- FACIL ----------------
    if n <= 2:
        a, b = random.randint(-15, 15), random.randint(-15, 15)
        return f"{a}+({b})", str(a + b)

    # ---------------- MEDIO ----------------
    elif n <= 4:
        a, b = random.randint(-12, 12), random.randint(-12, 12)
        return f"{a}*({b})", str(a * b)

    elif n <= 6:
        a, b, c = [random.randint(-20, 20) for _ in range(3)]
        return f"{a}+({b})*({c})", str(a + b * c)

    # ---------------- DIFICIL ----------------
    else:

        numeros = [random.randint(-30, 30) for _ in range(6)]

        operadores = [
            random.choice(["+", "-", "*"]),
            random.choice(["+", "-", "*"]),
            random.choice(["+", "-", "*"]),
            random.choice(["+", "-", "*"]),
            random.choice(["+", "-", "*"])
        ]

        expresion = f"({numeros[0]})"

        for op, num in zip(operadores, numeros[1:]):
            if op == "*":
                expresion += f"*({num})"
            else:
                expresion += f"{op}({num})"

        resultado = eval(expresion)

        pregunta = expresion.replace("*", "*")

        return pregunta, str(resultado)

MENU = 0
JUEGO = 1
GAMEOVER = 2

estado = MENU

clock = pygame.time.Clock()

async def main():

    global estado
    global nivel
    global tiempo_limite
    global vidas
    global aciertos
    global racha
    global mensaje
    global shake
    global particulas
    global pregunta
    global correcta
    global respuesta
    global inicio
    global record

    while True:

        for e in pygame.event.get():

            if e.type == pygame.QUIT:
                pygame.quit()
                raise SystemExit

            # ================= MENU =================

            if estado == MENU:

                if e.type == pygame.MOUSEBUTTONDOWN:

                    b1 = pygame.Rect(490,260,300,70)
                    b2 = pygame.Rect(490,360,300,70)
                    b3 = pygame.Rect(490,460,300,70)

                    if b1.collidepoint(e.pos):
                        nivel = 1
                        tiempo_limite = 12

                    elif b2.collidepoint(e.pos):
                        nivel = 2
                        tiempo_limite = 10

                    elif b3.collidepoint(e.pos):
                        nivel = 3
                        tiempo_limite = 8

                    else:
                        continue

                    vidas = 3
                    aciertos = 0
                    racha = 0
                    mensaje = ""
                    shake = 0
                    particulas = []

                    pregunta, correcta = operacion(nivel)
                    respuesta = ""

                    inicio = pygame.time.get_ticks()

                    estado = JUEGO

            # ================= JUEGO =================

            elif estado == JUEGO:

                if e.type == pygame.MOUSEBUTTONDOWN:

                    nums=["1","2","3","4","5","6","7","8","9","0","-"]

                    for i,n in enumerate(nums):

                        col=i%4
                        row=i//4

                        r=pygame.Rect(
                            260+col*140,
                            500+row*70,
                            110,
                            55
                        )

                        if r.collidepoint(e.pos):
                            respuesta += n

                    ok=pygame.Rect(900,500,180,60)
                    dele=pygame.Rect(900,580,180,60)

                    nums = ["1", "2", "3", "4",
                            "5", "6", "7", "8",
                            "9", "0", "-"]

                    for i, n in enumerate(nums):
                        col = i % 4
                        row = i // 4

                        x = 260 + col * 140
                        y = 500 + row * 70

                        boton(
                            n,
                            x,
                            y,
                            110,
                            55,
                            BG2
                        )

                    if dele.collidepoint(e.pos):
                        respuesta = respuesta[:-1]

                    if ok.collidepoint(e.pos):

                        if respuesta.strip()==correcta:

                            aciertos += 1
                            racha += 1

                            for _ in range(60):

                                particulas.append([
                                    ANCHO//2,
                                    230,
                                    random.uniform(-12,12),
                                    random.uniform(-12,12),
                                    random.randint(8,16)
                                ])

                            mensaje="CORRECTO!"

                            if aciertos % 5 == 0:

                                nivel += 1

                                if tiempo_limite > 3:
                                    tiempo_limite -= 0.2

                                mensaje=f"LEVEL UP {nivel}"

                        else:

                            vidas -= 1
                            racha = 0
                            shake = 18
                            mensaje=f"ERROR: {correcta}"

                        if aciertos > record:

                            record = aciertos
                            guardar_record(record)

                        respuesta=""
                        pregunta,correcta=operacion(nivel)

                        inicio=pygame.time.get_ticks()

            # ================= GAME OVER =================

            elif estado == GAMEOVER:

                if e.type == pygame.MOUSEBUTTONDOWN:

                    retry = pygame.Rect(
                        470,
                        470,
                        340,
                        80
                    )

                    if retry.collidepoint(e.pos):
                        estado = MENU

        # =====================================
        # ACTUALIZACION
        # =====================================

        if estado == JUEGO:

            restante=max(
                0,
                tiempo_limite -
                (pygame.time.get_ticks()-inicio)/1000
            )

            if restante<=0:

                vidas -= 1
                racha = 0

                mensaje=f"Tiempo! Era {correcta}"

                pregunta,correcta=operacion(nivel)

                respuesta=""

                inicio=pygame.time.get_ticks()

            if vidas<=0:
                estado = GAMEOVER

            # Actualizar particulas
            for p in particulas[:]:
                p[0] += p[2]
                p[1] += p[3]
                p[4] -= 0.25
                if p[4] <= 0:
                    particulas.remove(p)

        # =====================================
        # DIBUJADO
        # =====================================

        fondo()

        if estado == MENU:

            titulo=FONTG.render(
                "LEYES DE SIGNOS",
                True,
                WHITE
            )

            pantalla.blit(
                titulo,
                (
                    ANCHO//2-titulo.get_width()//2,
                    90
                )
            )

            boton("FACIL",490,260,300,70,BG2)
            boton("MEDIA",490,360,300,70,BG3)
            boton("DIFICIL",490,460,300,70,RED)

        elif estado == JUEGO:

            if shake>0:
                shake-=1

            off=random.randint(
                -shake,
                shake
            ) if shake>0 else 0

            card=pygame.Rect(
                220+off,
                120,
                840,
                220
            )

            pygame.draw.rect(
                pantalla,
                BG2,
                card,
                border_radius=25
            )

            pygame.draw.rect(
                pantalla,
                WHITE,
                card,
                3,
                border_radius=25
            )

            t=FONTG.render(
                pregunta,
                True,
                WHITE
            )

            pantalla.blit(
                t,
                (
                    ANCHO//2-t.get_width()//2+off,
                    180
                )
            )

            rtxt=FONTM.render(
                respuesta,
                True,
                YELLOW
            )

            pantalla.blit(
                rtxt,
                (
                    ANCHO//2-rtxt.get_width()//2,
                    285
                )
            )

            pantalla.blit(
                FONTM.render(
                    "V"*vidas,
                    True,
                    RED
                ),
                (30,20)
            )

            pantalla.blit(
                FONT.render(
                    f"Nivel {nivel}",
                    True,
                    WHITE
                ),
                (30,90)
            )

            pantalla.blit(
                FONT.render(
                    f"Aciertos {aciertos}",
                    True,
                    WHITE
                ),
                (30,130)
            )

            pantalla.blit(
                FONT.render(
                    f"Record {record}",
                    True,
                    YELLOW
                ),
                (30,170)
            )

            pantalla.blit(
                FONT.render(
                    f"Racha {racha}",
                    True,
                    BG4
                ),
                (30,210)
            )

            pantalla.blit(
                FONT.render(
                    f"Tiempo: {restante:.1f}s",
                    True,
                    YELLOW
                ),
                (30,250)
            )

            barra_x, barra_y = 30, 290
            barra_w, barra_h = 220, 25

            pygame.draw.rect(pantalla,(40,40,40),(barra_x,barra_y,barra_w,barra_h),border_radius=8)

            porcentaje = max(0, restante/tiempo_limite)

            pygame.draw.rect(
                pantalla,
                BG3,
                (barra_x,barra_y,int(barra_w*porcentaje),barra_h),
                border_radius=8
            )

            pygame.draw.rect(
                pantalla,
                WHITE,
                (barra_x,barra_y,barra_w,barra_h),
                2,
                border_radius=8
            )

            msg = FONT.render(mensaje,True,YELLOW)
            pantalla.blit(msg,(ANCHO//2-msg.get_width()//2,360))

            nums = ["1", "2", "3", "4",
                    "5", "6", "7", "8",
                    "9", "0", "-"]

            for i, n in enumerate(nums):
                col = i % 4
                row = i // 4

                x = 260 + col * 140
                y = 500 + row * 70

                boton(
                    n,
                    x,
                    y,
                    110,
                    55,
                    BG2
                )

            for p in particulas:
                pygame.draw.circle(
                    pantalla,
                    YELLOW,
                    (int(p[0]), int(p[1])),
                    max(1,int(p[4]))
                )

            boton("OK",900,500,180,60,BG3)
            boton("DEL",900,580,180,60,RED)

        elif estado == GAMEOVER:

            go = FONTG.render(
                "GAME OVER",
                True,
                RED
            )

            pantalla.blit(
                go,
                (
                    ANCHO//2-go.get_width()//2,
                    150
                )
            )

            pantalla.blit(
                FONTM.render(
                    f"Puntaje: {aciertos}",
                    True,
                    WHITE
                ),
                (500,280)
            )

            pantalla.blit(
                FONTM.render(
                    f"Record: {record}",
                    True,
                    YELLOW
                ),
                (500,340)
            )

            boton(
                "REINTENTAR",
                470,
                470,
                340,
                80,
                BG3
            )

        scanlines()

        pygame.display.flip()

        clock.tick(60)

        await asyncio.sleep(0)

asyncio.run(main())